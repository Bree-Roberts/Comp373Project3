package model.transaction;

public interface theRegister {
	abstract public void register();

}