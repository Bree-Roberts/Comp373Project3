package model.transaction;

class pantsProduct extends Product {

	String productType = "Blue Jeans ";
	int pantsStock = 50;
	int currentPantsStock = pantsStock;
	int purchasedPantsStockNumber = 0;
	public double price2 = 20.55;

	
	public pantsProduct(theRegister cashier1, theRegister cashier2) {
		super(cashier1, cashier2);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void storeBrand () {
		System.out.print(productType);
		System.out.print("Pants Unit Price: ");
		System.out.println(price2);
		cashier1.register();
		cashier2.register();
	}
	public int removePantsFromStockList(int purchasedPantsStockNumber) {
		return pantsStock--;
	}
	
}
 
 

