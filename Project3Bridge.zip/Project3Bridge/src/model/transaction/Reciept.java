package model.transaction;

public class Reciept implements theRegister {
	//the first implementation for the pattern
	
	public void register() {
		System.out.println("Transaction Succesful");
		
	}
}

