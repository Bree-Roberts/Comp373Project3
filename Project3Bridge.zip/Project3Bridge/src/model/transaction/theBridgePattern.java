package model.transaction;

public class theBridgePattern {
	public static void main(String[] args) {
		Product product1 = new shirtProduct(new Reciept(), new Transaction());
		product1.storeBrand();
		Product product2 = new pantsProduct(new Reciept(), new Transaction());
		product2.storeBrand();
		Product product3 = new shoesProduct(new Reciept(),new Transaction());
		product3.storeBrand();
	}
}
