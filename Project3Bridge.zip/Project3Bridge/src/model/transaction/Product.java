package model.transaction;

 public abstract class Product { // this is the abstraction in the pattern
	public theRegister cashier1;
	public theRegister cashier2;
	
	public Product(theRegister cashier1, theRegister cashier2) {
		this.cashier1 = cashier1;
		this.cashier2 = cashier2;
	}
	
	abstract public void storeBrand();
}
 