package model.transaction;

class shoesProduct extends Product { //this includes all of the shirts in the stor

	String productType = "Gym Shoes"; 
	int shoesStock = 30;
	int currentShoesStock = shoesStock;
	int purchasedShoesStockNumber = 0;
	public double price3 = 30;
	
	public shoesProduct(theRegister cashier1, theRegister cashier2) {
		super(cashier1, cashier2);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void storeBrand () {
		System.out.print(productType);
		System.out.print(" Unit Price: ");
		System.out.println(price3);
		cashier1.register();
		cashier2.register();
	}
	
	public int removeShoesFromStockList(int purchasedShirtStockNumber) {
		return shoesStock--;
	}

}
 