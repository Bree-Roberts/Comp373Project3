package model.transaction;

class shirtProduct extends Product { //this includes all of the shirts in the stor

	String productType = "White Tee Shirt"; 
	int shirtStock = 100;
	int currentShirtStock = shirtStock;
	int purchasedShirtStockNumber = 0;
	public double price1 = 10.10;
	
	public shirtProduct(theRegister cashier1, theRegister cashier2) {
		super(cashier1, cashier2);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void storeBrand () {
		System.out.print(productType);
		System.out.print(" Unit Price: ");
		System.out.println(price1);
		cashier1.register();
		cashier2.register();
	}
	
	public int removeShirtFromStockList(int purchasedShirtStockNumber) {
		return shirtStock--;
	}
}
 
 

