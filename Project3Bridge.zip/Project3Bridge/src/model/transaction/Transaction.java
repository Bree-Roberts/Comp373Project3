package model.transaction;

public class Transaction implements theRegister{
	//the second implementation for the pattern
	String timeOfTransaction = "10:00";
		
	public void register() {
		System.out.print(timeOfTransaction);
		System.out.println(" Time of Transaction");
	}
	
}

